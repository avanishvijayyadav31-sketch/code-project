/* Main Application Module */
class RemoteDeskApp {
    constructor() {
        this.currentSection = 'dashboard';
        this.init();
    }

    init() {
        this.setupNavigation();
        this.setupModals();
        this.setupEventListeners();
        this.startConnectionMonitoring();
        
        console.log('RemoteDesk Pro initialized');
    }

    setupNavigation() {
        // Handle navigation clicks
        document.querySelectorAll('a[href^="#"]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const target = e.target.getAttribute('href').substring(1);
                this.navigateToSection(target);
            });
        });
    }

    setupModals() {
        // Setup modal event listeners
        const connectionModal = document.getElementById('newConnectionModal');
        if (connectionModal) {
            connectionModal.addEventListener('shown.bs.modal', () => {
                document.getElementById('remoteDeviceId').focus();
            });
        }
    }

    setupEventListeners() {
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl+N for new connection
            if (e.ctrlKey && e.key === 'n') {
                e.preventDefault();
                this.showNewConnection();
            }
            
            // F5 to refresh
            if (e.key === 'F5') {
                e.preventDefault();
                this.refreshCurrentSection();
            }
        });

        // Connection status indicator
        this.updateConnectionStatus();
        setInterval(() => {
            this.updateConnectionStatus();
        }, 5000);
    }

    navigateToSection(section) {
        // Hide all sections
        document.getElementById('dashboardSection').style.display = 'none';
        document.getElementById('webrtcSection').style.display = 'none';
        
        // Show target section
        switch (section) {
            case 'dashboard':
                document.getElementById('dashboardSection').style.display = 'block';
                if (window.dashboardManager) {
                    window.dashboardManager.loadDashboard();
                }
                break;
            case 'webrtc':
            case 'sessions':
                document.getElementById('webrtcSection').style.display = 'block';
                break;
            default:
                document.getElementById('dashboardSection').style.display = 'block';
        }
        
        this.currentSection = section;
    }

    showNewConnection() {
        const modal = new bootstrap.Modal(document.getElementById('newConnectionModal'));
        modal.show();
    }

    showWebRTCTest() {
        this.navigateToSection('webrtc');
    }

    showStatistics() {
        showAlert('Statistics feature coming soon!', 'info');
    }

    refreshCurrentSection() {
        switch (this.currentSection) {
            case 'dashboard':
                if (window.dashboardManager) {
                    window.dashboardManager.loadDashboard();
                }
                break;
            case 'webrtc':
                // Refresh WebRTC test section
                break;
        }
    }

    updateConnectionStatus() {
        const statusDot = document.getElementById('connectionStatus');
        const latencyElement = document.getElementById('latency');
        const qualityElement = document.getElementById('quality');
        
        if (!statusDot) return;

        // Simulate connection status
        const isConnected = navigator.onLine;
        const latency = isConnected ? Math.floor(Math.random() * 30) + 15 : 0; // 15-45ms
        const quality = this.calculateConnectionQuality(latency);

        statusDot.className = `status-dot bg-${isConnected ? 'success' : 'danger'}`;
        
        if (latencyElement) {
            latencyElement.textContent = isConnected ? latency : '--';
        }
        
        if (qualityElement) {
            qualityElement.textContent = isConnected ? quality : '--';
        }
    }

    calculateConnectionQuality(latency) {
        if (latency < 20) return 'Excellent';
        if (latency < 50) return 'Good';
        if (latency < 100) return 'Fair';
        return 'Poor';
    }

    startConnectionMonitoring() {
        // Monitor connection health
        setInterval(() => {
            this.performConnectionCheck();
        }, 10000); // Check every 10 seconds
    }

    performConnectionCheck() {
        // Simulate connection monitoring
        const random = Math.random();
        
        if (random < 0.1) { // 10% chance of connection issue
            this.handleConnectionIssue();
        }
    }

    handleConnectionIssue() {
        console.warn('Connection issue detected');
        // In a real app, this would attempt to reconnect
        this.updateConnectionStatus();
    }

    // Utility methods
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    formatDuration(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        
        if (hours > 0) {
            return `${hours}h ${minutes % 60}m`;
        } else if (minutes > 0) {
            return `${minutes}m ${seconds % 60}s`;
        } else {
            return `${seconds}s`;
        }
    }

    generateId() {
        return 'id_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
}

// Global app instance
window.remoteDeskApp = new RemoteDeskApp();

// Global functions for UI interactions
function showNewConnection() {
    window.remoteDeskApp.showNewConnection();
}

function showWebRTCTest() {
    window.remoteDeskApp.showWebRTCTest();
}

function showStatistics() {
    window.remoteDeskApp.showStatistics();
}

function refreshSessions() {
    if (window.dashboardManager) {
        window.dashboardManager.loadDashboard();
    }
}

function viewSession(sessionId) {
    if (window.dashboardManager) {
        window.dashboardManager.sessions.forEach(session => {
            if (session.id === sessionId) {
                showAlert(`Session Details:\nID: ${session.id}\nStatus: ${session.status}\nLatency: ${session.latency}ms\nDuration: ${window.remoteDeskApp.formatDuration(session.duration)}`, 'info');
            }
        });
    }
}

function terminateSession(sessionId) {
    if (confirm('Are you sure you want to terminate this session?')) {
        if (window.dashboardManager) {
            window.dashboardManager.terminateSession(sessionId).then(result => {
                if (result.success) {
                    showAlert('Session terminated successfully', 'success');
                } else {
                    showAlert('Failed to terminate session: ' + result.error, 'danger');
                }
            });
        }
    }
}

function initiateConnection() {
    const form = document.getElementById('connectionForm');
    const formData = new FormData(form);
    
    const connectionData = {
        remoteDeviceId: document.getElementById('remoteDeviceId').value,
        connectionType: document.getElementById('connectionType').value,
        accessPassword: document.getElementById('accessPassword').value
    };

    // Simulate connection initiation
    showAlert(`Connecting to device ${connectionData.remoteDeviceId}...`, 'info');
    
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('newConnectionModal'));
    modal.hide();

    // Simulate connection process
    setTimeout(() => {
        showAlert('Connection request sent to remote device', 'success');
    }, 2000);
}

// Initialize sample data for demo
function initializeSampleData() {
    // Add sample users if none exist
    fetch('tables/users').then(r => r.json()).then(async result => {
        if (!result.data || result.data.length === 0) {
            const sampleUsers = [
                {
                    id: 'user_admin',
                    email: 'admin@remotedesk.com',
                    password_hash: btoa('admin123'),
                    username: 'admin',
                    full_name: 'Administrator',
                    role: 'admin',
                    is_verified: true,
                    last_login: Date.now(),
                    created_at: Date.now(),
                    updated_at: Date.now()
                },
                {
                    id: 'user_demo',
                    email: 'demo@remotedesk.com',
                    password_hash: btoa('demo123'),
                    username: 'demo',
                    full_name: 'Demo User',
                    role: 'user',
                    is_verified: true,
                    last_login: null,
                    created_at: Date.now() - 86400000,
                    updated_at: Date.now() - 86400000
                }
            ];

            for (const user of sampleUsers) {
                await fetch('tables/users', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(user)
                });
            }
        }
    });

    // Add sample sessions
    fetch('tables/sessions').then(r => r.json()).then(async result => {
        if (!result.data || result.data.length === 0) {
            const sampleSessions = [
                {
                    id: 'session_1',
                    user_id: 'user_demo',
                    session_id: 'session_1',
                    host_device_id: 'desktop-001',
                    client_device_id: 'laptop-002',
                    status: 'active',
                    connection_type: 'control',
                    start_time: Date.now() - 3600000,
                    end_time: null,
                    duration: 3600000,
                    latency: 25,
                    quality: 'good',
                    bytes_transferred: 52428800,
                    ip_address: '192.168.1.100',
                    user_agent: navigator.userAgent
                },
                {
                    id: 'session_2',
                    user_id: 'user_demo',
                    session_id: 'session_2',
                    host_device_id: 'mobile-001',
                    client_device_id: 'tablet-001',
                    status: 'pending',
                    connection_type: 'view',
                    start_time: Date.now() - 1800000,
                    end_time: null,
                    duration: 0,
                    latency: null,
                    quality: 'connecting',
                    bytes_transferred: 0,
                    ip_address: '192.168.1.101',
                    user_agent: navigator.userAgent
                }
            ];

            for (const session of sampleSessions) {
                await fetch('tables/sessions', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(session)
                });
            }
        }
    });
}

// Initialize sample data when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeSampleData();
});