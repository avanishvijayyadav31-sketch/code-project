// Signaling server implementation for WebRTC connections
class SignalingServer {
    constructor() {
        this.clients = new Map();
        this.rooms = new Map();
        this.setupMessageHandling();
    }
    
    setupMessageHandling() {
        // Listen for signaling messages in localStorage
        setInterval(() => {
            // Check for messages for this client
            const messages = this.getMessages();
            messages.forEach(message => {
                this.handleMessage(message);
            });
        }, 500);
    }
    
    getMessages() {
        const messages = [];
        const keys = [];
        
        // Get all message keys from localStorage
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith('signal_')) {
                try {
                    const message = JSON.parse(localStorage.getItem(key));
                    messages.push(message);
                    keys.push(key);
                } catch (e) {
                    console.error('Failed to parse message:', key);
                }
            }
        }
        
        // Remove processed messages
        keys.forEach(key => localStorage.removeItem(key));
        
        return messages;
    }
    
    handleMessage(message) {
        console.log('Processing message:', message);
        
        switch (message.type) {
            case 'join':
                this.handleJoin(message);
                break;
            case 'offer':
                this.handleOffer(message);
                break;
            case 'answer':
                this.handleAnswer(message);
                break;
            case 'ice-candidate':
                this.handleIceCandidate(message);
                break;
            case 'leave':
                this.handleLeave(message);
                break;
        }
    }
    
    handleJoin(message) {
        const { clientId, roomId } = message;
        
        // Store client info
        this.clients.set(clientId, {
            id: clientId,
            roomId: roomId,
            timestamp: Date.now()
        });
        
        // Create or join room
        if (!this.rooms.has(roomId)) {
            this.rooms.set(roomId, {
                id: roomId,
                clients: new Set(),
                created: Date.now()
            });
        }
        
        const room = this.rooms.get(roomId);
        room.clients.add(clientId);
        
        console.log(`Client ${clientId} joined room ${roomId}`);
    }
    
    handleOffer(message) {
        const { from, to, offer } = message;
        
        // Forward offer to target client
        this.sendToClient(to, {
            type: 'offer',
            offer: offer,
            from: from
        });
    }
    
    handleAnswer(message) {
        const { from, to, answer } = message;
        
        // Forward answer to target client
        this.sendToClient(to, {
            type: 'answer',
            answer: answer,
            from: from
        });
    }
    
    handleIceCandidate(message) {
        const { from, to, candidate } = message;
        
        // Forward ICE candidate to target client
        this.sendToClient(to, {
            type: 'ice-candidate',
            candidate: candidate,
            from: from
        });
    }
    
    handleLeave(message) {
        const { clientId, roomId } = message;
        
        // Remove client from room
        if (this.rooms.has(roomId)) {
            const room = this.rooms.get(roomId);
            room.clients.delete(clientId);
            
            // Remove room if empty
            if (room.clients.size === 0) {
                this.rooms.delete(roomId);
            }
        }
        
        // Remove client
        this.clients.delete(clientId);
        
        console.log(`Client ${clientId} left room ${roomId}`);
    }
    
    sendToClient(clientId, message) {
        // Store message in localStorage for target client
        const key = `signal_${clientId}`;
        const fullMessage = {
            ...message,
            timestamp: Date.now()
        };
        
        localStorage.setItem(key, JSON.stringify(fullMessage));
    }
    
    // Utility methods
    getRoomClients(roomId) {
        if (this.rooms.has(roomId)) {
            return Array.from(this.rooms.get(roomId).clients);
        }
        return [];
    }
    
    getClientRooms(clientId) {
        const rooms = [];
        this.rooms.forEach((room, roomId) => {
            if (room.clients.has(clientId)) {
                rooms.push(roomId);
            }
        });
        return rooms;
    }
    
    cleanup() {
        // Remove old messages and inactive clients
        const now = Date.now();
        const timeout = 30000; // 30 seconds
        
        // Clean up old clients
        this.clients.forEach((client, clientId) => {
            if (now - client.timestamp > timeout) {
                this.clients.delete(clientId);
                console.log(`Removed inactive client: ${clientId}`);
            }
        });
        
        // Clean up empty rooms
        this.rooms.forEach((room, roomId) => {
            if (room.clients.size === 0) {
                this.rooms.delete(roomId);
                console.log(`Removed empty room: ${roomId}`);
            }
        });
    }
}

// Create global signaling server instance
const signalingServer = new SignalingServer();

// Cleanup every 60 seconds
setInterval(() => {
    signalingServer.cleanup();
}, 60000);

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SignalingServer;
}