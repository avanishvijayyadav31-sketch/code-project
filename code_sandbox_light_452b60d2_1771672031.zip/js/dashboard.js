/* Dashboard Management Module */
class DashboardManager {
    constructor() {
        this.refreshInterval = null;
        this.sessions = [];
        this.devices = [];
        this.init();
    }

    init() {
        this.loadDashboard();
        this.startAutoRefresh();
    }

    async loadDashboard() {
        try {
            await Promise.all([
                this.loadSessions(),
                this.loadDevices(),
                this.loadStatistics()
            ]);
            this.updateUI();
        } catch (error) {
            console.error('Failed to load dashboard:', error);
        }
    }

    async loadSessions() {
        try {
            const response = await fetch('tables/sessions');
            const result = await response.json();
            this.sessions = result.data || [];
        } catch (error) {
            console.error('Failed to load sessions:', error);
            this.sessions = [];
        }
    }

    async loadDevices() {
        try {
            const response = await fetch('tables/devices');
            const result = await response.json();
            this.devices = result.data || [];
        } catch (error) {
            console.error('Failed to load devices:', error);
            this.devices = [];
        }
    }

    async loadStatistics() {
        // Calculate statistics from sessions and devices
        this.stats = {
            activeSessions: this.sessions.filter(s => s.status === 'active').length,
            onlineDevices: this.devices.filter(d => d.is_online).length,
            pendingRequests: this.sessions.filter(s => s.status === 'pending').length,
            totalUsers: (await fetch('tables/users').then(r => r.json()).then(r => r.data) || []).length
        };
    }

    updateUI() {
        // Update statistics cards
        document.getElementById('activeSessions').textContent = this.stats.activeSessions;
        document.getElementById('onlineDevices').textContent = this.stats.onlineDevices;
        document.getElementById('pendingRequests').textContent = this.stats.pendingRequests;
        document.getElementById('totalUsers').textContent = this.stats.totalUsers;

        // Update sessions table
        this.updateSessionsTable();
    }

    updateSessionsTable() {
        const tbody = document.getElementById('sessionsTable');
        if (!tbody) return;

        tbody.innerHTML = '';

        if (this.sessions.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-muted">
                        <i class="fas fa-info-circle me-1"></i>No active sessions
                    </td>
                </tr>
            `;
            return;
        }

        this.sessions.forEach(session => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><code>${session.id.substring(0, 8)}...</code></td>
                <td>${session.host_device_id || 'Unknown'}</td>
                <td>${session.client_device_id || 'Unknown'}</td>
                <td>
                    <span class="badge bg-${this.getStatusColor(session.status)}">
                        ${session.status}
                    </span>
                </td>
                <td>${session.latency ? session.latency + 'ms' : '--'}</td>
                <td>${this.formatTime(session.start_time)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="viewSession('${session.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="terminateSession('${session.id}')">
                        <i class="fas fa-stop"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    getStatusColor(status) {
        const colors = {
            'active': 'success',
            'pending': 'warning',
            'paused': 'secondary',
            'terminated': 'danger',
            'failed': 'danger'
        };
        return colors[status] || 'secondary';
    }

    formatTime(timestamp) {
        if (!timestamp) return '--';
        const date = new Date(timestamp);
        return date.toLocaleString();
    }

    startAutoRefresh() {
        this.refreshInterval = setInterval(() => {
            this.loadDashboard();
        }, 30000); // Refresh every 30 seconds
    }

    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }

    async createSession(sessionData) {
        try {
            const newSession = {
                id: this.generateSessionId(),
                user_id: window.authManager.getCurrentUser()?.id,
                session_id: this.generateSessionId(),
                host_device_id: sessionData.hostDeviceId,
                client_device_id: sessionData.clientDeviceId,
                status: 'pending',
                connection_type: sessionData.connectionType || 'view',
                start_time: Date.now(),
                end_time: null,
                duration: 0,
                latency: null,
                quality: 'connecting',
                bytes_transferred: 0,
                ip_address: sessionData.ipAddress || 'Unknown',
                user_agent: navigator.userAgent
            };

            const response = await fetch('tables/sessions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newSession)
            });

            if (response.ok) {
                this.sessions.push(newSession);
                this.updateUI();
                return {success: true, session: newSession};
            } else {
                throw new Error('Failed to create session');
            }
        } catch (error) {
            console.error('Failed to create session:', error);
            return {success: false, error: error.message};
        }
    }

    async terminateSession(sessionId) {
        try {
            const session = this.sessions.find(s => s.id === sessionId);
            if (!session) {
                throw new Error('Session not found');
            }

            session.status = 'terminated';
            session.end_time = Date.now();
            session.duration = session.end_time - session.start_time;

            const response = await fetch(`tables/sessions/${sessionId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(session)
            });

            if (response.ok) {
                this.updateUI();
                return {success: true};
            } else {
                throw new Error('Failed to terminate session');
            }
        } catch (error) {
            console.error('Failed to terminate session:', error);
            return {success: false, error: error.message};
        }
    }

    generateSessionId() {
        return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // Real-time updates (simulated)
    simulateRealTimeUpdates() {
        setInterval(() => {
            // Simulate latency updates
            this.sessions.forEach(session => {
                if (session.status === 'active') {
                    session.latency = Math.floor(Math.random() * 50) + 20; // 20-70ms
                    session.bytes_transferred += Math.floor(Math.random() * 1000000); // Random data transfer
                }
            });

            // Update UI if dashboard is visible
            if (document.getElementById('dashboardSection').style.display !== 'none') {
                this.updateUI();
            }
        }, 2000); // Update every 2 seconds
    }
}

// Global dashboard instance
window.dashboardManager = new DashboardManager();

// Global functions
function refreshSessions() {
    if (window.dashboardManager) {
        window.dashboardManager.loadSessions().then(() => {
            window.dashboardManager.updateUI();
            showAlert('Sessions refreshed', 'success');
        });
    }
}

function viewSession(sessionId) {
    const session = window.dashboardManager.sessions.find(s => s.id === sessionId);
    if (session) {
        showAlert(`Session Details:\nID: ${session.id}\nStatus: ${session.status}\nLatency: ${session.latency}ms`, 'info');
    }
}

function terminateSession(sessionId) {
    if (confirm('Are you sure you want to terminate this session?')) {
        window.dashboardManager.terminateSession(sessionId).then(result => {
            if (result.success) {
                showAlert('Session terminated successfully', 'success');
            } else {
                showAlert('Failed to terminate session: ' + result.error, 'danger');
            }
        });
    }
}