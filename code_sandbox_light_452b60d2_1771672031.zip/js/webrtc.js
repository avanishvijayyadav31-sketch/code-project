// WebRTC Remote Desktop Implementation
class WebRTCRemoteDesktop {
    constructor() {
        this.localConnection = null;
        this.remoteConnection = null;
        this.dataChannel = null;
        this.remoteDataChannel = null;
        this.localStream = null;
        this.remoteStream = null;
        this.isHost = false;
        this.remoteId = null;
        this.myId = null;
        this.signalingSocket = null;
        this.peerConnection = null;
        this.remoteVideo = null;
        this.isConnected = false;
        
        // STUN/TURN servers
        this.iceServers = [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
            { urls: 'stun:stun2.l.google.com:19302' }
        ];
        
        this.init();
    }
    
    init() {
        this.remoteVideo = document.getElementById('remoteVideo');
        this.setupSignaling();
    }
    
    setupSignaling() {
        // Create a simple signaling system using localStorage for demo
        // In production, this would be a WebSocket server
        this.signalingSocket = {
            send: (message) => {
                const key = `signal_${message.to}`;
                localStorage.setItem(key, JSON.stringify(message));
                console.log('Signal sent:', message);
            },
            onMessage: (callback) => {
                this.messageCallback = callback;
                // Check for messages periodically
                setInterval(() => {
                    const key = `signal_${this.myId}`;
                    const message = localStorage.getItem(key);
                    if (message) {
                        localStorage.removeItem(key);
                        callback(JSON.parse(message));
                    }
                }, 1000);
            }
        };
    }
    
    async initializeWebRTC(remoteId, myId) {
        this.remoteId = remoteId;
        this.myId = myId;
        
        try {
            // Create peer connection
            this.peerConnection = new RTCPeerConnection({
                iceServers: this.iceServers
            });
            
            // Handle incoming stream
            this.peerConnection.ontrack = (event) => {
                console.log('Received remote stream');
                this.remoteVideo.srcObject = event.streams[0];
                this.isConnected = true;
            };
            
            // Handle connection state changes
            this.peerConnection.onconnectionstatechange = () => {
                console.log('Connection state:', this.peerConnection.connectionState);
                if (this.peerConnection.connectionState === 'connected') {
                    this.isConnected = true;
                    updateStatus('online', `Connected to ${remoteId}`);
                } else if (this.peerConnection.connectionState === 'disconnected' || 
                          this.peerConnection.connectionState === 'failed') {
                    this.isConnected = false;
                    updateStatus('offline', 'Disconnected');
                }
            };
            
            // Handle ICE candidates
            this.peerConnection.onicecandidate = (event) => {
                if (event.candidate) {
                    this.signalingSocket.send({
                        type: 'ice-candidate',
                        candidate: event.candidate,
                        to: this.remoteId,
                        from: this.myId
                    });
                }
            };
            
            // Create data channel for file transfer and control
            this.dataChannel = this.peerConnection.createDataChannel('remoteDesktop', {
                ordered: true
            });
            
            this.setupDataChannel(this.dataChannel);
            
            // Handle incoming data channel
            this.peerConnection.ondatachannel = (event) => {
                this.remoteDataChannel = event.channel;
                this.setupDataChannel(this.remoteDataChannel);
            };
            
            // Start the connection process
            await this.createAndSendOffer();
            
        } catch (error) {
            console.error('Failed to initialize WebRTC:', error);
            throw error;
        }
    }
    
    setupDataChannel(channel) {
        channel.onopen = () => {
            console.log('Data channel opened');
            this.isConnected = true;
        };
        
        channel.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleDataChannelMessage(data);
        };
        
        channel.onclose = () => {
            console.log('Data channel closed');
            this.isConnected = false;
        };
        
        channel.onerror = (error) => {
            console.error('Data channel error:', error);
        };
    }
    
    handleDataChannelMessage(data) {
        switch (data.type) {
            case 'mouse-move':
                this.handleRemoteMouseMove(data.x, data.y);
                break;
            case 'mouse-click':
                this.handleRemoteMouseClick(data.x, data.y, data.button);
                break;
            case 'keyboard':
                this.handleRemoteKeyboard(data.key);
                break;
            case 'file-transfer':
                this.handleIncomingFile(data);
                break;
            case 'screen-share-stop':
                this.handleScreenShareStop();
                break;
        }
    }
    
    async createAndSendOffer() {
        try {
            // Get screen stream
            this.localStream = await navigator.mediaDevices.getDisplayMedia({
                video: {
                    width: { ideal: 1920 },
                    height: { ideal: 1080 },
                    frameRate: { ideal: 30 }
                },
                audio: false
            });
            
            // Add stream to peer connection
            this.localStream.getTracks().forEach(track => {
                this.peerConnection.addTrack(track, this.localStream);
            });
            
            // Create offer
            const offer = await this.peerConnection.createOffer({
                offerToReceiveVideo: true,
                offerToReceiveAudio: false
            });
            
            await this.peerConnection.setLocalDescription(offer);
            
            // Send offer through signaling
            this.signalingSocket.send({
                type: 'offer',
                offer: offer,
                to: this.remoteId,
                from: this.myId
            });
            
            // Handle screen share stop
            this.localStream.getVideoTracks()[0].onended = () => {
                this.handleScreenShareStop();
            };
            
        } catch (error) {
            console.error('Failed to create offer:', error);
            throw error;
        }
    }
    
    async handleOffer(offer, from) {
        try {
            this.remoteId = from;
            
            // Create peer connection if not exists
            if (!this.peerConnection) {
                this.peerConnection = new RTCPeerConnection({
                    iceServers: this.iceServers
                });
                
                this.peerConnection.ontrack = (event) => {
                    console.log('Received remote stream');
                    this.remoteVideo.srcObject = event.streams[0];
                    this.isConnected = true;
                };
                
                this.peerConnection.onconnectionstatechange = () => {
                    if (this.peerConnection.connectionState === 'connected') {
                        this.isConnected = true;
                        updateStatus('online', `Connected to ${from}`);
                    }
                };
                
                this.peerConnection.onicecandidate = (event) => {
                    if (event.candidate) {
                        this.signalingSocket.send({
                            type: 'ice-candidate',
                            candidate: event.candidate,
                            to: this.remoteId,
                            from: this.myId
                        });
                    }
                };
                
                this.peerConnection.ondatachannel = (event) => {
                    this.remoteDataChannel = event.channel;
                    this.setupDataChannel(this.remoteDataChannel);
                };
            }
            
            await this.peerConnection.setRemoteDescription(offer);
            
            // Create answer
            const answer = await this.peerConnection.createAnswer();
            await this.peerConnection.setLocalDescription(answer);
            
            // Send answer
            this.signalingSocket.send({
                type: 'answer',
                answer: answer,
                to: this.remoteId,
                from: this.myId
            });
            
        } catch (error) {
            console.error('Failed to handle offer:', error);
            throw error;
        }
    }
    
    async handleAnswer(answer) {
        try {
            await this.peerConnection.setRemoteDescription(answer);
        } catch (error) {
            console.error('Failed to handle answer:', error);
            throw error;
        }
    }
    
    async handleIceCandidate(candidate) {
        try {
            await this.peerConnection.addIceCandidate(candidate);
        } catch (error) {
            console.error('Failed to handle ICE candidate:', error);
        }
    }
    
    // Remote control functions
    sendMouseMove(x, y) {
        if (this.dataChannel && this.dataChannel.readyState === 'open') {
            this.dataChannel.send(JSON.stringify({
                type: 'mouse-move',
                x: x,
                y: y
            }));
        }
    }
    
    sendMouseClick(x, y, button = 'left') {
        if (this.dataChannel && this.dataChannel.readyState === 'open') {
            this.dataChannel.send(JSON.stringify({
                type: 'mouse-click',
                x: x,
                y: y,
                button: button
            }));
        }
    }
    
    sendKeyboard(key) {
        if (this.dataChannel && this.dataChannel.readyState === 'open') {
            this.dataChannel.send(JSON.stringify({
                type: 'keyboard',
                key: key
            }));
        }
    }
    
    // File transfer functions
    sendFiles(files) {
        if (this.dataChannel && this.dataChannel.readyState === 'open') {
            Array.from(files).forEach(file => {
                const reader = new FileReader();
                reader.onload = (e) => {
                    const data = {
                        type: 'file-transfer',
                        name: file.name,
                        size: file.size,
                        type: file.type,
                        data: e.target.result
                    };
                    this.dataChannel.send(JSON.stringify(data));
                };
                reader.readAsDataURL(file);
            });
        }
    }
    
    handleIncomingFile(fileData) {
        console.log('Received file:', fileData.name);
        // Convert base64 to blob and download
        const link = document.createElement('a');
        link.href = fileData.data;
        link.download = fileData.name;
        link.click();
        
        alert(`File received: ${fileData.name}`);
    }
    
    handleRemoteMouseMove(x, y) {
        const cursor = document.getElementById('remoteCursor');
        const video = document.getElementById('remoteVideo');
        const rect = video.getBoundingClientRect();
        
        cursor.style.left = (x * rect.width) + 'px';
        cursor.style.top = (y * rect.height) + 'px';
        cursor.style.display = 'block';
    }
    
    handleRemoteMouseClick(x, y, button) {
        console.log(`Remote click at ${x}, ${y} with ${button} button`);
        // In a real implementation, this would control the remote system
    }
    
    handleRemoteKeyboard(key) {
        console.log(`Remote key pressed: ${key}`);
        // In a real implementation, this would send keys to the remote system
    }
    
    handleScreenShareStop() {
        console.log('Screen share stopped');
        this.dataChannel.send(JSON.stringify({
            type: 'screen-share-stop'
        }));
        this.disconnectWebRTC();
    }
    
    disconnectWebRTC() {
        if (this.peerConnection) {
            this.peerConnection.close();
            this.peerConnection = null;
        }
        
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => track.stop());
            this.localStream = null;
        }
        
        if (this.dataChannel) {
            this.dataChannel.close();
            this.dataChannel = null;
        }
        
        if (this.remoteDataChannel) {
            this.remoteDataChannel.close();
            this.remoteDataChannel = null;
        }
        
        this.isConnected = false;
        
        // Hide remote video
        if (this.remoteVideo) {
            this.remoteVideo.srcObject = null;
        }
        
        // Hide cursor
        document.getElementById('remoteCursor').style.display = 'none';
    }
}

// Global functions for the UI
let webrtcManager;

function initializeWebRTC(remoteId, myId) {
    webrtcManager = new WebRTCRemoteDesktop();
    return webrtcManager.initializeWebRTC(remoteId, myId);
}

function disconnectWebRTC() {
    if (webrtcManager) {
        webrtcManager.disconnectWebRTC();
    }
}

function sendFiles(files) {
    if (webrtcManager) {
        webrtcManager.sendFiles(files);
    }
}

function updateStatus(status, message) {
    // This function is called from the HTML page
    if (typeof window.updateStatus === 'function') {
        window.updateStatus(status, message);
    }
}

// Handle incoming signaling messages
function handleSignalingMessage(message) {
    if (!webrtcManager) {
        webrtcManager = new WebRTCRemoteDesktop();
    }
    
    switch (message.type) {
        case 'offer':
            webrtcManager.handleOffer(message.offer, message.from);
            break;
        case 'answer':
            webrtcManager.handleAnswer(message.answer);
            break;
        case 'ice-candidate':
            webrtcManager.handleIceCandidate(message.candidate);
            break;
    }
}

// Set up mouse and keyboard event handlers for remote control
document.addEventListener('DOMContentLoaded', function() {
    const remoteVideo = document.getElementById('remoteVideo');
    
    if (remoteVideo) {
        // Mouse events
        remoteVideo.addEventListener('mousemove', function(e) {
            if (webrtcManager && webrtcManager.isConnected) {
                const rect = this.getBoundingClientRect();
                const x = (e.clientX - rect.left) / rect.width;
                const y = (e.clientY - rect.top) / rect.height;
                webrtcManager.sendMouseMove(x, y);
            }
        });
        
        remoteVideo.addEventListener('click', function(e) {
            if (webrtcManager && webrtcManager.isConnected) {
                const rect = this.getBoundingClientRect();
                const x = (e.clientX - rect.left) / rect.width;
                const y = (e.clientY - rect.top) / rect.height;
                webrtcManager.sendMouseClick(x, y);
            }
        });
        
        // Keyboard events
        document.addEventListener('keydown', function(e) {
            if (webrtcManager && webrtcManager.isConnected) {
                webrtcManager.sendKeyboard(e.key);
            }
        });
    }
});