/* WebRTC Engine for Remote Desktop */
class WebRTCEngine {
    constructor() {
        this.localStream = null;
        this.remoteStream = null;
        this.peerConnection = null;
        this.dataChannel = null;
        this.currentRoom = null;
        this.localPeerId = this.generatePeerId();
        this.remotePeerId = null;
        this.isInitiator = false;
        this.connectionState = 'disconnected';
        this.iceServers = [
            {urls: 'stun:stun.l.google.com:19302'},
            {urls: 'stun:stun1.l.google.com:19302'},
            {urls: 'stun:stun2.l.google.com:19302'},
            // Add more STUN servers for better connectivity
        ];
        
        this.setupPeriodicCleanup();
    }

    async startScreenShare() {
        try {
            const constraints = {
                video: {
                    cursor: 'always',
                    displaySurface: 'monitor',
                    width: { ideal: 1920 },
                    height: { ideal: 1080 },
                    frameRate: { ideal: 30 }
                },
                audio: false
            };

            this.localStream = await navigator.mediaDevices.getDisplayMedia(constraints);
            
            // Handle screen share ending
            this.localStream.getVideoTracks()[0].onended = () => {
                this.handleScreenShareEnded();
            };

            this.updateLocalVideo();
            this.log('Screen sharing started successfully');
            
            // Auto-create room when screen sharing starts
            await this.createRoom('screen-share-' + Date.now());
            
            return true;
        } catch (error) {
            console.error('Failed to start screen share:', error);
            this.log('Failed to start screen sharing: ' + error.message, 'error');
            return false;
        }
    }

    async startCameraStream() {
        try {
            const constraints = {
                video: {
                    width: { ideal: 1280 },
                    height: { ideal: 720 },
                    frameRate: { ideal: 30 }
                },
                audio: false
            };

            this.localStream = await navigator.mediaDevices.getUserMedia(constraints);
            this.updateLocalVideo();
            this.log('Camera stream started');
            return true;
        } catch (error) {
            console.error('Failed to start camera:', error);
            this.log('Failed to start camera: ' + error.message, 'error');
            return false;
        }
    }

    stopLocalStream() {
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => track.stop());
            this.localStream = null;
            
            const videoElement = document.getElementById('localVideo');
            if (videoElement) {
                videoElement.srcObject = null;
            }
            
            this.log('Local stream stopped');
        }
    }

    updateLocalVideo() {
        const videoElement = document.getElementById('localVideo');
        if (videoElement && this.localStream) {
            videoElement.srcObject = this.localStream;
        }
    }

    async createRoom(roomId) {
        try {
            this.currentRoom = roomId;
            const room = await window.signalingAPI.createRoom({
                id: roomId,
                peerId: this.localPeerId
            });
            
            this.log('Room created: ' + roomId);
            this.startPollingForMessages();
            return room;
        } catch (error) {
            console.error('Failed to create room:', error);
            this.log('Failed to create room: ' + error.message, 'error');
            return null;
        }
    }

    async joinRoom(roomId, remotePeerId = null) {
        try {
            this.currentRoom = roomId;
            this.remotePeerId = remotePeerId;
            
            const room = await window.signalingAPI.joinRoom(roomId, this.localPeerId, {
                name: 'Remote User',
                joined: Date.now()
            });
            
            this.log('Joined room: ' + roomId);
            this.startPollingForMessages();
            return room;
        } catch (error) {
            console.error('Failed to join room:', error);
            this.log('Failed to join room: ' + error.message, 'error');
            return null;
        }
    }

    async createPeerConnection(isInitiator = false) {
        try {
            this.isInitiator = isInitiator;
            
            this.peerConnection = new RTCPeerConnection({
                iceServers: this.iceServers,
                iceCandidatePoolSize: 10,
                bundlePolicy: 'max-bundle',
                rtcpMuxPolicy: 'require'
            });

            // Add local stream
            if (this.localStream) {
                this.localStream.getTracks().forEach(track => {
                    this.peerConnection.addTrack(track, this.localStream);
                });
            }

            // Create data channel for file transfer and chat
            if (this.isInitiator) {
                this.dataChannel = this.peerConnection.createDataChannel('remote-desktop', {
                    ordered: true,
                    maxRetransmits: 3
                });
                this.setupDataChannel();
            } else {
                this.peerConnection.ondatachannel = (event) => {
                    this.dataChannel = event.channel;
                    this.setupDataChannel();
                };
            }

            // Handle incoming streams
            this.peerConnection.ontrack = (event) => {
                this.handleRemoteStream(event);
            };

            // Handle ICE candidates
            this.peerConnection.onicecandidate = (event) => {
                if (event.candidate) {
                    this.sendSignalingMessage('ice-candidate', {
                        candidate: event.candidate
                    });
                }
            };

            // Handle connection state changes
            this.peerConnection.onconnectionstatechange = () => {
                this.handleConnectionStateChange();
            };

            // Handle ICE connection state
            this.peerConnection.oniceconnectionstatechange = () => {
                this.log(`ICE connection state: ${this.peerConnection.iceConnectionState}`);
            };

            this.connectionState = 'connecting';
            this.log('Peer connection created');
            return true;
        } catch (error) {
            console.error('Failed to create peer connection:', error);
            this.log('Failed to create peer connection: ' + error.message, 'error');
            return false;
        }
    }

    setupDataChannel() {
        if (!this.dataChannel) return;

        this.dataChannel.onopen = () => {
            this.log('Data channel opened');
            this.connectionState = 'connected';
            this.updateConnectionStatus();
        };

        this.dataChannel.onmessage = (event) => {
            this.handleDataChannelMessage(event.data);
        };

        this.dataChannel.onclose = () => {
            this.log('Data channel closed');
            this.connectionState = 'disconnected';
            this.updateConnectionStatus();
        };

        this.dataChannel.onerror = (error) => {
            this.log('Data channel error: ' + error.message, 'error');
        };
    }

    handleDataChannelMessage(data) {
        try {
            const message = JSON.parse(data);
            
            switch (message.type) {
                case 'file-transfer':
                    this.handleFileTransferMessage(message);
                    break;
                case 'chat':
                    this.handleChatMessage(message);
                    break;
                case 'remote-control':
                    this.handleRemoteControlMessage(message);
                    break;
                case 'ping':
                    this.sendDataChannelMessage({ type: 'pong', timestamp: message.timestamp });
                    break;
                case 'pong':
                    this.handlePong(message);
                    break;
            }
        } catch (error) {
            console.error('Failed to handle data channel message:', error);
        }
    }

    async createOffer() {
        try {
            if (!this.peerConnection) {
                await this.createPeerConnection(true);
            }

            const offer = await this.peerConnection.createOffer({
                offerToReceiveVideo: true,
                offerToReceiveAudio: false
            });

            await this.peerConnection.setLocalDescription(offer);

            this.sendSignalingMessage('offer', {
                sdp: offer
            });

            this.log('Offer created and sent');
            return offer;
        } catch (error) {
            console.error('Failed to create offer:', error);
            this.log('Failed to create offer: ' + error.message, 'error');
            return null;
        }
    }

    async createAnswer() {
        try {
            if (!this.peerConnection) {
                await this.createPeerConnection(false);
            }

            const answer = await this.peerConnection.createAnswer();
            await this.peerConnection.setLocalDescription(answer);

            this.sendSignalingMessage('answer', {
                sdp: answer
            });

            this.log('Answer created and sent');
            return answer;
        } catch (error) {
            console.error('Failed to create answer:', error);
            this.log('Failed to create answer: ' + error.message, 'error');
            return null;
        }
    }

    async handleOffer(offer, fromPeerId) {
        try {
            this.remotePeerId = fromPeerId;
            
            if (!this.peerConnection) {
                await this.createPeerConnection(false);
            }

            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
            this.log('Offer received and processed');

            // Automatically create answer
            await this.createAnswer();
            return true;
        } catch (error) {
            console.error('Failed to handle offer:', error);
            this.log('Failed to handle offer: ' + error.message, 'error');
            return false;
        }
    }

    async handleAnswer(answer, fromPeerId) {
        try {
            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
            this.log('Answer received and processed');
            return true;
        } catch (error) {
            console.error('Failed to handle answer:', error);
            this.log('Failed to handle answer: ' + error.message, 'error');
            return false;
        }
    }

    async handleIceCandidate(candidate, fromPeerId) {
        try {
            await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
            this.log('ICE candidate added');
            return true;
        } catch (error) {
            console.error('Failed to handle ICE candidate:', error);
            this.log('Failed to handle ICE candidate: ' + error.message, 'error');
            return false;
        }
    }

    handleRemoteStream(event) {
        if (event.streams && event.streams[0]) {
            this.remoteStream = event.streams[0];
            const videoElement = document.getElementById('remoteVideo');
            if (videoElement) {
                videoElement.srcObject = this.remoteStream;
                videoElement.play().catch(e => {
                    console.error('Failed to play remote video:', e);
                });
            }
            this.log('Remote stream received');
        }
    }

    handleConnectionStateChange() {
        const state = this.peerConnection.connectionState;
        this.log(`Connection state: ${state}`);
        
        switch (state) {
            case 'connected':
                this.connectionState = 'connected';
                this.startLatencyMonitoring();
                break;
            case 'disconnected':
            case 'failed':
                this.connectionState = 'disconnected';
                break;
            case 'closed':
                this.connectionState = 'closed';
                break;
        }
        
        this.updateConnectionStatus();
    }

    sendSignalingMessage(type, payload) {
        if (this.currentRoom && this.remotePeerId) {
            window.signalingAPI.sendSignalingMessage(
                this.currentRoom,
                this.localPeerId,
                this.remotePeerId,
                { type, payload }
            );
        }
    }

    sendDataChannelMessage(message) {
        if (this.dataChannel && this.dataChannel.readyState === 'open') {
            this.dataChannel.send(JSON.stringify(message));
            return true;
        }
        return false;
    }

    startPollingForMessages() {
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
        }

        this.pollingInterval = setInterval(async () => {
            const messages = await window.signalingAPI.pollMessages(this.localPeerId);
            
            for (const message of messages) {
                this.handleSignalingMessage(message);
            }
        }, 1000); // Poll every second
    }

    handleSignalingMessage(message) {
        const { type, payload, fromPeerId } = message;

        switch (type) {
            case 'offer':
                this.handleOffer(payload.sdp, fromPeerId);
                break;
            case 'answer':
                this.handleAnswer(payload.sdp, fromPeerId);
                break;
            case 'ice-candidate':
                this.handleIceCandidate(payload.candidate, fromPeerId);
                break;
            case 'connection-request':
                this.handleConnectionRequest(fromPeerId, payload);
                break;
        }
    }

    async handleConnectionRequest(fromPeerId, requestData) {
        this.log(`Connection request from ${fromPeerId}`);
        
        // Auto-accept connection requests for now
        // In production, you would show a prompt to the user
        await this.joinRoom(requestData.roomId, fromPeerId);
        await this.createPeerConnection(false);
    }

    // Latency monitoring
    startLatencyMonitoring() {
        if (this.latencyInterval) {
            clearInterval(this.latencyInterval);
        }

        this.latencyInterval = setInterval(() => {
            const pingStart = Date.now();
            this.sendDataChannelMessage({
                type: 'ping',
                timestamp: pingStart
            });
        }, 5000); // Ping every 5 seconds
    }

    handlePong(message) {
        const latency = Date.now() - message.timestamp;
        this.updateLatencyDisplay(latency);
    }

    updateLatencyDisplay(latency) {
        const latencyElement = document.getElementById('connLatency');
        if (latencyElement) {
            latencyElement.textContent = latency + 'ms';
        }

        // Update quality indicator
        const qualityElement = document.getElementById('connQuality');
        if (qualityElement) {
            let quality = 'Poor';
            if (latency < 50) quality = 'Excellent';
            else if (latency < 150) quality = 'Good';
            else if (latency < 300) quality = 'Fair';
            
            qualityElement.textContent = quality;
        }
    }

    updateConnectionStatus() {
        const statusElement = document.getElementById('connStatus');
        if (statusElement) {
            const statusClass = this.connectionState === 'connected' ? 'success' : 
                               this.connectionState === 'connecting' ? 'warning' : 'danger';
            statusElement.className = `badge bg-${statusClass}`;
            statusElement.textContent = this.connectionState.charAt(0).toUpperCase() + this.connectionState.slice(1);
        }
    }

    setupPeriodicCleanup() {
        setInterval(() => {
            window.signalingServer.cleanup();
        }, 300000); // Clean up every 5 minutes
    }

    handleScreenShareEnded() {
        this.log('Screen sharing ended');
        this.stopLocalStream();
        
        // Notify remote peer
        this.sendDataChannelMessage({
            type: 'screen-share-ended'
        });
    }

    disconnect() {
        this.log('Disconnecting...');
        
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
        }
        
        if (this.latencyInterval) {
            clearInterval(this.latencyInterval);
        }
        
        if (this.dataChannel) {
            this.dataChannel.close();
        }
        
        if (this.peerConnection) {
            this.peerConnection.close();
        }
        
        this.stopLocalStream();
        
        this.connectionState = 'disconnected';
        this.updateConnectionStatus();
        
        // Leave room
        if (this.currentRoom && this.localPeerId) {
            window.signalingServer.leaveRoom(this.currentRoom, this.localPeerId);
        }
        
        this.log('Disconnected');
    }

    generatePeerId() {
        return 'peer_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    log(message, type = 'info') {
        console.log(`[WebRTC] ${message}`);
        
        const logElement = document.getElementById('connectionLog');
        if (logElement) {
            const timestamp = new Date().toLocaleTimeString();
            const logEntry = document.createElement('div');
            logEntry.className = `log-entry log-${type}`;
            logEntry.innerHTML = `<small>[${timestamp}] ${message}</small>`;
            
            logElement.appendChild(logEntry);
            logElement.scrollTop = logElement.scrollHeight;
        }
    }
}

// Global WebRTC engine
window.webrtcEngine = new WebRTCEngine();