/* Authentication Module */
class AuthManager {
    constructor() {
        this.currentUser = null;
        this.token = localStorage.getItem('token');
        this.init();
    }

    init() {
        if (this.token) {
            this.validateToken();
        } else {
            this.showLogin();
        }
    }

    async validateToken() {
        try {
            // In a real app, this would validate with the server
            const response = await fetch('tables/users', {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });
            
            if (response.ok) {
                this.currentUser = JSON.parse(localStorage.getItem('user') || '{}');
                this.showDashboard();
            } else {
                this.logout();
            }
        } catch (error) {
            console.error('Token validation failed:', error);
            this.logout();
        }
    }

    async login(email, password) {
        try {
            // Simulate authentication - in real app, this would be a server request
            const users = await this.getUsers();
            const user = users.find(u => u.email === email);
            
            if (user && this.verifyPassword(password, user.password_hash)) {
                // Generate a simple token (in real app, this comes from server)
                this.token = btoa(JSON.stringify({userId: user.id, timestamp: Date.now()}));
                this.currentUser = user;
                
                localStorage.setItem('token', this.token);
                localStorage.setItem('user', JSON.stringify(user));
                
                this.showDashboard();
                return {success: true, user};
            } else {
                throw new Error('Invalid credentials');
            }
        } catch (error) {
            console.error('Login failed:', error);
            return {success: false, error: error.message};
        }
    }

    async register(userData) {
        try {
            // Check if user exists
            const users = await this.getUsers();
            if (users.find(u => u.email === userData.email)) {
                throw new Error('User already exists');
            }

            // Hash password (in real app, use proper hashing)
            const passwordHash = btoa(userData.password);
            
            const newUser = {
                id: this.generateId(),
                email: userData.email,
                username: userData.username,
                password_hash: passwordHash,
                full_name: userData.fullName,
                role: 'user',
                is_verified: false,
                last_login: null,
                created_at: Date.now(),
                updated_at: Date.now()
            };

            // Save to database
            await this.saveUser(newUser);
            
            return {success: true, user: newUser};
        } catch (error) {
            console.error('Registration failed:', error);
            return {success: false, error: error.message};
        }
    }

    logout() {
        this.token = null;
        this.currentUser = null;
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        this.showLogin();
    }

    verifyPassword(password, hash) {
        // Simple verification - in real app, use proper password verification
        return btoa(password) === hash;
    }

    generateId() {
        return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    async getUsers() {
        try {
            const response = await fetch('tables/users');
            const result = await response.json();
            return result.data || [];
        } catch (error) {
            console.error('Failed to fetch users:', error);
            return [];
        }
    }

    async saveUser(user) {
        try {
            await fetch('tables/users', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(user)
            });
        } catch (error) {
            console.error('Failed to save user:', error);
            throw error;
        }
    }

    showLogin() {
        document.getElementById('loginSection').style.display = 'flex';
        document.getElementById('dashboardSection').style.display = 'none';
        document.getElementById('webrtcSection').style.display = 'none';
    }

    showDashboard() {
        document.getElementById('loginSection').style.display = 'none';
        document.getElementById('dashboardSection').style.display = 'block';
        document.getElementById('webrtcSection').style.display = 'none';
        
        if (this.currentUser) {
            document.getElementById('userName').textContent = this.currentUser.username;
        }
        
        // Load dashboard data
        if (window.dashboardManager) {
            window.dashboardManager.loadDashboard();
        }
    }

    isAuthenticated() {
        return !!this.token;
    }

    getCurrentUser() {
        return this.currentUser;
    }
}

// Global auth instance
window.authManager = new AuthManager();

// Login form handler
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            const result = await window.authManager.login(email, password);
            
            if (result.success) {
                // Show success message
                showAlert('Login successful!', 'success');
            } else {
                // Show error message
                showAlert('Login failed: ' + result.error, 'danger');
            }
        });
    }
});

// Global functions
function logout() {
    window.authManager.logout();
}

function showRegister() {
    // For now, just show an alert. In a full app, this would show a registration form
    showAlert('Registration feature coming soon!', 'info');
}

function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 300px;';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.parentNode.removeChild(alertDiv);
        }
    }, 5000);
}